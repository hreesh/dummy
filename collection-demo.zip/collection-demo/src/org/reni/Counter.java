package org.reni;

public class Counter {
	
	public int count;
	
//	public synchronized void increment() {
//		count++;//count=count+1
//	}
//	
	public  void increment() {
		count++;//count=count+1
	}

}
