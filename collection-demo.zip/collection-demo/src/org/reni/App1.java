package org.reni;

import java.util.Set;
import java.util.TreeSet;

public class App1 {

	public static void main(String[] args) {
		
		Set<Employee> employees=new TreeSet<Employee>();
		
		employees.add(new Employee(1,"John","Male",23,35000));
		employees.add(new Employee(2,"Binu","Male",22,99000));
		employees.add(new Employee(3,"Asha","Female",23,67000));
		employees.add(new Employee(4,"Tod","Male",33,45000));
		employees.add(new Employee(5,"Tom","Male",55,86000));
		
		
		
		for (Employee employee : employees) {
			System.out.println(employee);
		}
		
		
		
		
		

	}

}
