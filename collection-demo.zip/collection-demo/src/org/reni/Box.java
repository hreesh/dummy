package org.reni;

public class Box<T> {
	
	private T item;
	
	public T getItem() {
		return item;
	}
	
	public void setItem(T item) {
		this.item=item;
	}
}
