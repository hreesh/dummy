package org.reni;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

public class App2 {

	public static void main(String[] args) {
//		Stack<String> stack=new Stack<>();
//		
//		stack.add("Sunil");
//		stack.add("Binu");
//		stack.add("Linda");
//		
//		String name=stack.pop();
//		
//		System.out.println(name);
//		
//		System.out.println("++++++++++++++++++++++++++++");
//		
//		
//		for (String string : stack) {
//			System.out.println(string);
//		}
//		
//		Queue<String> queue=new LinkedList<String>();
		Deque<String> queue=new LinkedList<String>();
		queue.push("Manu");
		queue.push("Binu");
		queue.push("Anil");
		
		String name=queue.removeLast();
		
		System.out.println(name);
		System.out.println();
		System.out.println();
		for (String string : queue) {
			System.out.println(string);
		} 
		
		
		
		
		
		

	}

}
