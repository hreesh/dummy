package org.reni;

import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

public class MainApp {
	
	public static void main(String[] args) {
		
//		List<String> names=new Vector<String>();
//		
//		ArrayList<Integer> numbers=new ArrayList<Integer>();
//		numbers.add(1);
//		numbers.add(10);
//		numbers.add(12);
//		numbers.add(8);
//		numbers.add(33);
//		numbers.add(22);
//		Collections.sort(numbers);
//		System.out.println();
//		for (Integer num : numbers) {
//			System.out.println(num);
//		}
//		System.out.println();
//		names.add("Manu");
//		names.add("Shivani");
//		names.add("Arun");
//		names.add("Suma");
//		names.add("Manu");
//		Collections.sort(names);
//		
//		for (String string : names) {
//			
//			System.out.println(string);
//		}
//		System.out.println("----------------");
//		String name=names.get(0);
//		System.out.println(name);
//		if(names.contains("Shivani")) {
//			System.out.println("Shivani Present");
//		}
//		names.add(1,"Anil");
//		for (String string : names) {
//			System.out.println(string);
//		}
//		System.out.println("==============================");
//		
//		Iterator<String> iter=names.iterator();
//		
//		while(iter.hasNext()) {
//			System.out.println(iter.next());
//		}
//		
	
//		Set<String> names=new TreeSet<String>();
//		names.add("Kiran");
//		names.add("Binu");
//		names.add("Charu");
//		names.add("Kiran");
//		
////		System.out.println(names.size());
////		System.out.println(names.remove("Binu"));
//		
//		for (String name : names) {
//			System.out.println(name);
//		}
		
		
		Map<Integer, String> data=new Hashtable<Integer, String>();
		
		data.put(3, "Manu");
		data.put(1, "Kiran");
		data.put(2, "Mark");
		
		for (Entry<Integer, String> entry : data.entrySet()) {
			
			
			System.out.println(entry.getKey()+ " "+ entry.getValue());
			
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
