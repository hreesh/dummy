package org.reni;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class App {

	public static void main(String[] args) {
		
		List<Integer> numbers=Arrays.asList(3,7,4,1,9);
		
		for (Integer num : numbers) {
			System.out.println(num);
		}
		System.out.println();
		
//		NumberSorter sorter=new NumberSorter();
		
//		Collections.sort(numbers,sorter);
		
		Collections.sort(numbers,new Comparator<Integer>() {

			@Override
			public int compare(Integer num1, Integer num2) {
				return -num1.compareTo(num2);
			}
			
			
		});
		
		for (Integer num : numbers) {
			System.out.println(num);
		}
		
		
		

	}

}

class NumberSorter implements Comparator<Integer>{

	@Override
	public int compare(Integer num1, Integer num2) {
		
//		if(num1>num2) {
//			return -1;
//		}
//		else if(num1<num2) {
//			return 1;
//		}
//		else {
//			return 0;
//		}
		
		return -num1.compareTo(num2);
	}
	
}
