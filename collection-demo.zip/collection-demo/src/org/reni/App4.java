package org.reni;

public class App4 {

	public static void main(String[] args) throws InterruptedException {
		
		Counter counter=new Counter();
		Employee lock=new Employee();
		
		Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				for(int i=0;i<10000;i++) {
					synchronized (lock) {
						counter.increment();
					}
					
				}
				
			}
		});
		Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
				for(int i=0;i<10000;i++) {
					synchronized (lock) {
						counter.increment();
					}
				}
				
			}
		});
		
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		
		
		System.out.println("The value of count is "+counter.count);

	}

}
