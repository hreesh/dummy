package org.reni;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class App5 {
	
	public static void main(String [] args) {
		
		ConcurrentHashMap<Integer, String> map=new ConcurrentHashMap<Integer, String>();
		
		CopyOnWriteArrayList<String> arr=new CopyOnWriteArrayList<String>();
		arr.add("abcd");
		
		Box<Integer> box=new Box<Integer>();
		
		box.setItem(23);
		System.out.println(box.getItem());
		
		Box<String> strBox=new Box<String>();
		strBox.setItem("Hello");
		
		System.out.println(strBox.getItem());
		
		Box<Employee> boxEmployee=new Box<Employee>();
		boxEmployee.setItem(new Employee(1,"Kiran","Male",23,45000));
		
		System.out.println(boxEmployee.getItem()); 
	
		
		
		
	}

}
