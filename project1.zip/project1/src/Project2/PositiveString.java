package Project2;

import java.util.Scanner;

public class PositiveString {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        
        while (true) {
            System.out.println("Enter a string to check if it is a positive string (or type 'exit' to quit):");
            input = scanner.nextLine();
            
            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting the program.");
                break;
            }
            
            if (isPositiveString(input)) {
                System.out.println(input + " is a positive string.");
            } else {
                System.out.println(input + " is not a positive string.");
            }
        }

        scanner.close();
    }

    public static boolean isPositiveString(String str) {
        for (int i = 0; i < str.length() - 1; i++) {
            if (str.charAt(i) > str.charAt(i + 1)) {
                return false;
            }
        }
        return true;
    }
}
