package Project2;

public class Positive {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int num=Integer.parseInt(args[0]);
	if(num<0) {
		System.out.println("number is negative");
	}else {
		System.out.println("the number is positive");
	}
}
}

