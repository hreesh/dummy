package Project2;

public class Hareesh34 {
	

		


			public static void main(String[] args) 
			{
				
			System.out.println("hai");
}

}




