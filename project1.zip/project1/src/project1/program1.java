package project1;

public class program1 {

	
	

		public class App {

			public static void main(String[] args) 
			{
				
			System.out.println("hai");
}

}
}
